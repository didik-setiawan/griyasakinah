<?php

// pengaturan durasi delete maximal 
$setup_bataswaktu = 2; // 2 = dua bulan (satuan nya bulan)

// modul modul, jika ada perubahan cek database nya
$modul_dashboard                            = 1;
$modul_pos_penjualan                        = 2;
$modul_pos_laporan                          = 3;
$modul_pos_faktur                           = 4;
$modul_pos_return                           = 5;
$modul_pos_biaya_kirim                      = 6;
$modul_pos                                  = 7;
$modul_inventory_produk                     = 8;
$modul_inventory_order                      = 9;
$modul_inventory_faktur_gudang              = 10;
$modul_inventory_return                     = 11;
$modul_inventory_check_stock                = 12;
$modul_inventory_stock_opname               = 13;
$modul_inventory                            = 14;
$modul_info_produk_kadaluarsa               = 15;
$modul_info_produk_top                      = 16;
$modul_purchasing_return                    = 17;
$modul_purchasing_shipping_cost             = 18;
$modul_info_produk                          = 19;
$modul_faktur_penjualan                     = 20;
$modul_faktur_pembelian                     = 21;
$modul_faktur                               = 22;
$modul_gaji_bonus_gaji                      = 23;
$modul_gaji_bonus_absensi                   = 24;
$modul_gaji_bonus_bonus_sales               = 25;
$modul_gaji_bonus                           = 26;
$modul_laporan_keuangan_kas_besar           = 27;
$modul_laporan_keuangan_kas_kecil           = 28;
$modul_laporan_keuangan_laporan_keuangan    = 29;
$modul_laporan_keuangan_laba_rugi           = 30;
$modul_laporan_keuangan                     = 31;
$modul_master_database_product              = 32;
$modul_master_database_product_category     = 33;
$modul_master_database_customer             = 34;
$modul_master_database_supplier             = 35;
$modul_master_database_sales                = 36;
$modul_master_database_employer             = 37;
$modul_master_database_store                = 38;
$modul_master_database_setting              = 39;
$modul_master_database                      = 40;
$modul_user_group                           = 42;
$modul_user_group_groups                    = 43;
$modul_user_group_module                    = 44;
$modul_user_group1                          = 45;
$modul_master_database_payment_methods      = 46;
$modul_laporan_keuangan_ppn                 = 47;
$modul_laporan_keuangan_ongkir              = 48;
$modul_faktur_tukar_faktur                  = 49;



?>